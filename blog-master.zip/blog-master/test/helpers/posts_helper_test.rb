require 'test_helper'

class PostsHelperTest < ActionView::TestCase
end
